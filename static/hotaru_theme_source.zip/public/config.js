window.__PRE_CONFIG__ = {
  header: 'Server Status',
  subHeader: 'Servers\' Probes Set up with ServerStatus',
  interval: 1.5,
  footer: '<p>Powered by <a href="https://github.com/komari-monitor/komari">Komari Monitor</a></br>Theme <a href="https://github.com/cokemine/ServerStatus-Hotaru">ServerStatus-Hotaru</a></p>'
};
