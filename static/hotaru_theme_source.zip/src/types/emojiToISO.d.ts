declare const emojiToISO: Record<string, string>;
export default emojiToISO;
