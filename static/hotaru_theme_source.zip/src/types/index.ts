// Komari API 节点基本信息
export interface NodeInfo {
  uuid: string;
  name: string;
  cpu_name: string;
  virtualization: string;
  arch: string;
  cpu_cores: number;
  os: string;
  gpu_name: string;
  region: string;
  mem_total: number;
  swap_total: number;
  disk_total: number;
  weight: number;
  price: number;
  billing_cycle: number;
  currency: string;
  expired_at: string | null;
  group: string;
  tags: string;
  created_at: string;
  updated_at: string;
}

// Komari API 实时状态数据
export interface NodeStatus {
  cpu: {
    usage: number;
  };
  ram: {
    total: number;
    used: number;
  };
  swap: {
    total: number;
    used: number;
  };
  load: {
    load1: number;
    load5: number;
    load15: number;
  };
  disk: {
    total: number;
    used: number;
  };
  network: {
    up: number;
    down: number;
    totalUp: number;
    totalDown: number;
  };
  connections: {
    tcp: number;
    udp: number;
  };
  uptime: number;
  process: number;
  message: string;
  updated_at: string;
}

// 合并后的服务器数据
export interface ServerItem extends NodeInfo {
  status?: NodeStatus;
  online: boolean;
}

// API 响应格式
export interface ApiResponse<T> {
  status: string;
  message: string;
  data: T;
}

// WebSocket 数据格式
export interface WebSocketData {
  data: {
    online: string[];
    data: { [uuid: string]: NodeStatus };
  };
  status: string;
}

// 兼容旧接口的类型（用于渐进式迁移）
export interface BoxItem {
  name: string;
  host: string;
  type: string;
  online4: boolean;
  online6: boolean;
  location: string;
  region: string;
  weight: number;
}

export interface StatusItem extends BoxItem {
  uptime: string;
  load: number;
  cpu: number;
  network_rx: number;
  network_tx: number;
  network_in: number;
  network_out: number;
  memory_total: number;
  memory_used: number;
  swap_total: number;
  swap_used: number;
  hdd_total: number;
  hdd_used: number;
  custom: string;
  cpu_name?: string;
  os?: string;
  arch?: string;
  virtualization?: string;
  cpu_cores?: number;
}

declare global {
  interface Window {
    __PRE_CONFIG__: {
      header: string;
      subHeader: string;
      interval: number;
      footer: string;
    };
  }
}
