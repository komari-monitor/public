import axios from 'axios';
import { NodeInfo, NodeStatus, ApiResponse, WebSocketData, ServerItem } from '@/types';
import KOMARI_CONFIG from '@/config/komari';

class KomariApi {
  private baseURL: string;
  private websocket: WebSocket | null = null;
  private onDataCallback: ((data: ServerItem[]) => void) | null = null;
  private onlineNodes: string[] = [];
  private nodeStatuses: { [uuid: string]: NodeStatus } = {};  private reconnectAttempts = 0;  private nodes: NodeInfo[] = [];
  private isReconnecting = false;
  private reconnectTimer: number | null = null;
  private pingTimer: number | null = null;

  constructor(baseURL: string = KOMARI_CONFIG.BASE_URL) {
    this.baseURL = baseURL;
    // 设置 axios 默认超时时间
    axios.defaults.timeout = KOMARI_CONFIG.API_TIMEOUT;
  }

  /**
   * 获取所有节点信息
   */
  async getNodes(): Promise<NodeInfo[]> {
    try {
      const response = await axios.get<ApiResponse<NodeInfo[]>>(`${this.baseURL}/api/nodes`);
      if (response.data.status === 'success') {
        this.nodes = response.data.data;
        if (KOMARI_CONFIG.DEBUG) {
          console.log('获取到节点信息:', this.nodes.length, '个节点');
        }
        return this.nodes;
      }
      throw new Error(response.data.message || '获取节点信息失败');
    } catch (error) {
      console.error('获取节点信息失败:', error);
      throw error;
    }
  }

  /**
   * 获取指定节点最近1分钟的历史数据
   */
  async getRecentNodeStatus(uuid: string): Promise<NodeStatus[]> {
    try {
      const response = await axios.get<ApiResponse<NodeStatus[]>>(`${this.baseURL}/api/recent/${uuid}`);
      if (response.data.status === 'success') {
        return response.data.data;
      }
      throw new Error(response.data.message || '获取节点状态失败');
    } catch (error) {
      console.error('获取节点状态失败:', error);
      throw error;
    }
  }

  /**
   * 获取站点公开属性
   */
  async getPublicSettings() {
    try {
      const response = await axios.get<ApiResponse<any>>(`${this.baseURL}/api/public`);
      if (response.data.status === 'success') {
        return response.data.data;
      }
      throw new Error(response.data.message || '获取站点设置失败');
    } catch (error) {
      console.error('获取站点设置失败:', error);
      throw error;
    }
  }  /**
   * 建立 WebSocket 连接获取实时数据
   */
  connectWebSocket(onData: (data: ServerItem[]) => void, onError?: (error: Event) => void) {
    // 如果正在重连，先清除之前的重连定时器
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    
    this.onDataCallback = onData;
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsURL = `${protocol}//${window.location.host}${this.baseURL}/api/clients`;
    
    if (KOMARI_CONFIG.DEBUG) {
      console.log('正在连接 WebSocket:', wsURL);
    }
    
    // 如果已有连接，先关闭
    if (this.websocket) {
      this.websocket.close();
    }
    
    this.websocket = new WebSocket(wsURL);
      this.websocket.onopen = () => {
      console.log('WebSocket 连接已建立');
      this.reconnectAttempts = 0;
      this.isReconnecting = false;
      // 发送获取数据请求
      this.websocket?.send('get');
      // 启动心跳检测
      this.startPing();
    };
    
    this.websocket.onmessage = (event) => {
      try {
        const wsData: WebSocketData = JSON.parse(event.data);
        if (wsData.status === 'success') {
          this.onlineNodes = wsData.data.online;
          this.nodeStatuses = wsData.data.data;
          if (KOMARI_CONFIG.DEBUG) {
            console.log('收到 WebSocket 数据，在线节点:', this.onlineNodes.length);
          }
          this.updateServerData();
        }
      } catch (error) {
        console.error('解析 WebSocket 数据失败:', error);
      }
    };
    
    this.websocket.onerror = (error) => {
      console.error('WebSocket 错误:', error);
      onError?.(error);
    };
    
    this.websocket.onclose = (event) => {
      console.log(`WebSocket 连接已关闭 (代码: ${event.code}, 原因: ${event.reason})`);
      
      // 只有在非手动关闭的情况下才尝试重连
      if (!this.isReconnecting && this.onDataCallback && event.code !== 1000) {
        this.scheduleReconnect(onData, onError);
      }
    };
  }

  /**
   * 安排重连
   */
  private scheduleReconnect(onData: (data: ServerItem[]) => void, onError?: (error: Event) => void) {
    // 检查是否需要重连
    if (KOMARI_CONFIG.WEBSOCKET_MAX_RETRIES !== -1 && 
        this.reconnectAttempts >= KOMARI_CONFIG.WEBSOCKET_MAX_RETRIES) {
      console.error('WebSocket 重连次数已达上限，停止重连');
      return;
    }
    
    this.isReconnecting = true;
    this.reconnectAttempts++;
    
    // 计算重连延迟（指数退避算法）
    const baseDelay = KOMARI_CONFIG.WEBSOCKET_RECONNECT_DELAY;
    const delay = Math.min(baseDelay * Math.pow(2, this.reconnectAttempts - 1), 30000); // 最大30秒
    
    console.log(`将在 ${delay}ms 后尝试重连 WebSocket (第 ${this.reconnectAttempts} 次)`);
    
    this.reconnectTimer = window.setTimeout(() => {
      if (this.onDataCallback) {
        this.connectWebSocket(onData, onError);
      }
    }, delay);
  }
  /**
   * 关闭 WebSocket 连接
   */
  disconnectWebSocket() {
    this.isReconnecting = true; // 设置标志位，防止自动重连
    
    // 清除重连定时器
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);      this.reconnectTimer = null;
    }
    
    if (this.websocket) {
      this.websocket.close(1000, '手动关闭'); // 正常关闭代码
      this.websocket = null;
    }
    
    // 停止心跳检测
    this.stopPing();
    
    this.onDataCallback = null;
    this.reconnectAttempts = 0;
    this.isReconnecting = false;
  }

  /**
   * 启动心跳检测
   */
  private startPing() {
    this.stopPing(); // 先清除之前的定时器
    
    if (KOMARI_CONFIG.WEBSOCKET_PING_INTERVAL > 0) {
      this.pingTimer = window.setInterval(() => {
        if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
          // 发送心跳请求
          this.websocket.send('get');
          if (KOMARI_CONFIG.DEBUG) {
            console.log('发送 WebSocket 心跳');
          }
        }
      }, KOMARI_CONFIG.WEBSOCKET_PING_INTERVAL);
    }
  }

  /**
   * 停止心跳检测
   */
  private stopPing() {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  /**
   * 更新服务器数据并通知回调
   */
  private async updateServerData() {
    if (!this.onDataCallback) return;
    
    try {
      // 如果还没有节点信息，先获取一次
      if (this.nodes.length === 0) {
        await this.getNodes();
      }
      
      const servers: ServerItem[] = this.nodes.map(node => ({
        ...node,
        status: this.nodeStatuses[node.uuid],
        online: this.onlineNodes.includes(node.uuid)
      }));
      
      this.onDataCallback(servers);
    } catch (error) {
      console.error('更新服务器数据失败:', error);
    }
  }
  /**
   * 获取合并后的服务器数据（节点信息 + 实时状态）
   */
  async getServers(): Promise<ServerItem[]> {
    try {
      if (this.nodes.length === 0) {
        await this.getNodes();
      }
      
      const servers: ServerItem[] = this.nodes.map(node => ({
        ...node,
        status: this.nodeStatuses[node.uuid],
        online: this.onlineNodes.includes(node.uuid)
      }));
      
      return servers;
    } catch (error) {
      console.error('获取服务器数据失败:', error);
      throw error;
    }
  }

  /**
   * 转换为兼容旧格式的数据
   */
  convertToLegacyFormat(servers: ServerItem[]): any[] {
    return servers.map(server => {
      const status = server.status;
      const baseData = {
        name: server.name,
        host: server.name, // 使用 name 作为 host
        //type: this.getServerType(server),
        type: server.virtualization || "未知",
        online4: server.online,
        online6: false, // Komari API 暂不支持 IPv6 状态
        location: server.region, // 直接使用 region 字段作为地区
        region: server.region,
        weight: server.weight || 0, // 如果没有权重，默认为 0
      };

      if (status && server.online) {
        return {
          ...baseData,
          uptime: this.formatUptime(status.uptime),
          load: status.load.load1,
          cpu: Math.round(status.cpu.usage * 100) / 100, // 保留两位小数
          network_rx: status.network.down,
          network_tx: status.network.up,
          network_in: status.network.totalDown,
          network_out: status.network.totalUp,
          memory_total: Math.round(server.mem_total / 1024), // 转换为 KB
          memory_used: Math.round(status.ram.used / 1024), // 转换为 KB
          swap_total: Math.round(server.swap_total / 1024), // 转换为 KB          swap_used: Math.round(status.swap.used / 1024), // 转换为 KB
          hdd_total: Math.round(server.disk_total / 1024 / 1024), // 转换为 MB
          hdd_used: Math.round(status.disk.used / 1024 / 1024), // 转换为 MB
          custom: '',
          // 添加额外信息用于折叠菜单
          cpu_name: server.cpu_name,
          os: server.os,
          arch: server.arch,
          virtualization: server.virtualization,
          cpu_cores: server.cpu_cores
        };
      } else {
        // 离线状态
        return {
          ...baseData,
          uptime: '离线',
          load: 0,
          cpu: 0,
          network_rx: 0,
          network_tx: 0,
          network_in: 0,
          network_out: 0,
          memory_total: Math.round(server.mem_total / 1024),
          memory_used: 0,
          swap_total: Math.round(server.swap_total / 1024),          swap_used: 0,
          hdd_total: Math.round(server.disk_total / 1024 / 1024),
          hdd_used: 0,
          custom: '',
          // 添加额外信息用于折叠菜单
          cpu_name: server.cpu_name,
          os: server.os,
          arch: server.arch,
          virtualization: server.virtualization,
          cpu_cores: server.cpu_cores
        };
      }
    });
  }
  /**
   * 获取服务器类型描述（系统名称的第一个单词）
   */
  private getServerType(server: ServerItem): string {
    if (server.os) {
      // 获取操作系统名称的第一个单词
      const firstWord = server.os.split(' ')[0];
      return firstWord || '未知';
    }
    return '未知';
  }

  /**
   * 格式化运行时间
   */
  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
      return `${days}天 ${hours}小时`;
    } else if (hours > 0) {
      return `${hours}小时 ${minutes}分钟`;
    } else {
      return `${minutes}分钟`;
    }
  }
}

// 创建全局实例
export const komariApi = new KomariApi();
export default KomariApi;
