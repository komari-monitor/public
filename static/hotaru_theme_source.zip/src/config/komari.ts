// Komari API 配置
export const KOMARI_CONFIG = {
  // Komari 服务器基础 URL，留空表示使用当前域名
  BASE_URL: '',
  
  // WebSocket 重连配置
  WEBSOCKET_RECONNECT_DELAY: 3000, // 初始重连延迟（毫秒）
  WEBSOCKET_MAX_RETRIES: -1, // 最大重试次数，-1 表示无限重试
  WEBSOCKET_PING_INTERVAL: 2000, // WebSocket 心跳间隔（毫秒）
  
  // API 请求超时时间
  API_TIMEOUT: 10000, // 10秒
  
  // 是否启用调试模式
  DEBUG: false,
  
  // 获取更新间隔的函数
  getUpdateInterval(): number {
    try {
      // 从全局配置获取间隔，默认1.5秒
      return (window.__PRE_CONFIG__?.interval || 1.5) * 1000;
    } catch {
      return 1500; // 默认1.5秒
    }
  }
};

// 在开发环境中可以覆盖配置
if (process.env.NODE_ENV === 'development') {
  // 开发环境配置
  KOMARI_CONFIG.DEBUG = true;
}

export default KOMARI_CONFIG;
