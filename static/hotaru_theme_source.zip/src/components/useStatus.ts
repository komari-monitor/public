import { computed } from 'vue';
import { BoxItem, StatusItem } from '@/types';

interface Props {
  server: StatusItem | BoxItem;
}

export default (props: Props) => {
  const getStatus = computed((): boolean => {
    const server = props.server as StatusItem;
    // 支持新旧两种在线状态判断方式
    if ('online4' in server || 'online6' in server) {
      return server.online4 || server.online6;
    }
    // 如果没有 online4/online6 字段，则根据是否有 CPU 数据来判断
    return server.cpu !== undefined && server.cpu >= 0;
  });

  const getCpuStatus = computed((): number => {
    const server = props.server as StatusItem;
    if (server.cpu === undefined || server.cpu < 0) {
      return 0;
    }
    return Math.min(100, Math.max(0, server.cpu));
  });

  const getRAMStatus = computed((): number => {
    const server = props.server as StatusItem;
    if (server.memory_total === undefined || server.memory_total <= 0 || 
        server.memory_used === undefined || server.memory_used < 0) {
      return 0;
    }
    return Math.min(100, Math.round((server.memory_used / server.memory_total) * 100));
  });

  const getHDDStatus = computed((): number => {
    const server = props.server as StatusItem;
    if (server.hdd_total === undefined || server.hdd_total <= 0 || 
        server.hdd_used === undefined || server.hdd_used < 0) {
      return 0;
    }
    return Math.min(100, Math.round((server.hdd_used / server.hdd_total) * 100));
  });

  const getProcessBarStatus = computed(() => (data: number) => {
    if (data > 90) return 'error';
    else if (data > 70) return 'warning';
    else return 'success';
  });

  const tableRowByteConvert = computed(() => (data: number): string => {
    if (isNaN(data) || data < 0) return '0B';
    if (data < 1024) return data.toFixed(0) + 'B';
    else if (data < 1024 * 1024) return (data / 1024).toFixed(0) + 'K';
    else if (data < 1024 * 1024 * 1024) return (data / 1024 / 1024).toFixed(1) + 'M';
    else if (data < 1024 * 1024 * 1024 * 1024) return (data / 1024 / 1024 / 1024).toFixed(2) + 'G';
    else return (data / 1024 / 1024 / 1024 / 1024).toFixed(2) + 'T';
  });

  const expandRowByteConvert = computed(() => (data: number): string => {
    if (isNaN(data) || data < 0) return '0 B';
    if (data < 1024) return data.toFixed(0) + ' B';
    else if (data < 1024 * 1024) return (data / 1024).toFixed(2) + ' KiB';
    else if (data < 1024 * 1024 * 1024) return (data / 1024 / 1024).toFixed(2) + ' MiB';
    else if (data < 1024 * 1024 * 1024 * 1024) return (data / 1024 / 1024 / 1024).toFixed(2) + ' GiB';
    else return (data / 1024 / 1024 / 1024 / 1024).toFixed(2) + ' TiB';
  });

  return {
    getStatus,
    getCpuStatus,
    getRAMStatus,
    getHDDStatus,
    getProcessBarStatus,
    tableRowByteConvert,
    expandRowByteConvert
  };
};
